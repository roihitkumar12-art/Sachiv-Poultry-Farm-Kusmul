/* ==========================================================================
   APP.JS — Core site behaviour: forms, WhatsApp orders, misc utilities
   ========================================================================== */

const FARM_PHONE = '+919926030249'; // TODO: replace with real farm number
const FARM_WHATSAPP = '919926030249'; // TODO: replace (no + , no spaces)

document.addEventListener('DOMContentLoaded', () => {

  /* ---- Set current year in footer ---- */
  const yearEls = document.querySelectorAll('[data-year]');
  yearEls.forEach(el => el.textContent = new Date().getFullYear());

  /* ---- Contact / Enquiry Form Validation ---- */
  const contactForm = document.querySelector('#contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      let valid = true;

      const fields = contactForm.querySelectorAll('[required]');
      fields.forEach(field => {
        const fieldWrap = field.closest('.field');
        if (!field.value.trim()) {
          valid = false;
          fieldWrap && fieldWrap.classList.add('invalid');
        } else {
          fieldWrap && fieldWrap.classList.remove('invalid');
        }
      });

      // Phone number basic validation
      const phoneField = contactForm.querySelector('[name="phone"]');
      if (phoneField && phoneField.value.trim()) {
        const phonePattern = /^[6-9]\d{9}$/;
        const cleaned = phoneField.value.replace(/\D/g, '').slice(-10);
        if (!phonePattern.test(cleaned)) {
          valid = false;
          phoneField.closest('.field').classList.add('invalid');
        }
      }

      if (!valid) return;

      // Build WhatsApp message from form data
      const name = contactForm.querySelector('[name="name"]')?.value || '';
      const phone = contactForm.querySelector('[name="phone"]')?.value || '';
      const product = contactForm.querySelector('[name="product"]')?.value || '';
      const message = contactForm.querySelector('[name="message"]')?.value || '';

      const successBox = contactForm.querySelector('.form-success');
      if (successBox) {
        successBox.classList.add('show');
        successBox.textContent = 'Dhanyawad! Aapka message mil gaya hai. Hum jald hi aapse sampark karenge. / Thank you! We will contact you shortly.';
      }

      contactForm.reset();

      // Optional: open WhatsApp with prefilled enquiry (uncomment to enable)
      // const waText = encodeURIComponent(`Namaste, mera naam ${name} hai. Mujhe ${product || 'products'} ke baare me jaankari chahiye. ${message}`);
      // window.open(`https://wa.me/${FARM_WHATSAPP}?text=${waText}`, '_blank');
    });

    // Remove invalid state as user types
    contactForm.querySelectorAll('input, textarea, select').forEach(field => {
      field.addEventListener('input', () => {
        field.closest('.field')?.classList.remove('invalid');
      });
    });
  }

  /* ---- Quick order buttons -> WhatsApp with prefilled product message ---- */
  document.querySelectorAll('[data-whatsapp-order]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const productName = btn.getAttribute('data-whatsapp-order') || 'Desi Murgi / Ande';
      const text = encodeURIComponent(`Namaste Sachiv Poultry Farm Kusmul, mujhe "${productName}" order karna hai. Kripya rate aur availability bataye.`);
      window.open(`https://wa.me/${FARM_WHATSAPP}?text=${text}`, '_blank');
    });
  });

  /* ---- Newsletter / blog subscribe (if present) ---- */
  const subscribeForm = document.querySelector('#subscribeForm');
  if (subscribeForm) {
    subscribeForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const msg = subscribeForm.querySelector('.form-success');
      if (msg) msg.classList.add('show');
      subscribeForm.reset();
    });
  }

  /* ---- Smooth-scroll for on-page anchor links ---- */
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      const targetId = link.getAttribute('href');
      if (targetId.length > 1) {
        const target = document.querySelector(targetId);
        if (target) {
          e.preventDefault();
          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }
    });
  });

});
