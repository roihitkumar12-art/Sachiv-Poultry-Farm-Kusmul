/* ==========================================================================
   THREE.JS SETUP — Ambient floating "husk/feather" particle effect
   Loaded only on pages with a #heroCanvas element. Uses CDN three.js r128.
   Falls back silently (no errors) if three.js CDN is unavailable or the
   canvas is not present — keeps the site fully functional without it.
   ========================================================================== */

(function () {
  const canvas = document.querySelector('#heroCanvas');
  if (!canvas) return;

  // Respect reduced motion preference
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src;
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  loadScript('https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js')
    .then(initScene)
    .catch(() => { /* three.js failed to load — hero still works without it */ });

  function initScene() {
    if (typeof THREE === 'undefined') return;

    const width = canvas.clientWidth;
    const height = canvas.clientHeight;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 100);
    camera.position.z = 12;

    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Particle field — soft haldi/husk colored dots drifting like chaff in the wind
    const count = 90;
    const positions = new Float32Array(count * 3);
    const speeds = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 20;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 12;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 10;
      speeds[i] = 0.15 + Math.random() * 0.35;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const material = new THREE.PointsMaterial({
      color: 0xD9A62E,
      size: 0.09,
      transparent: true,
      opacity: 0.45,
      sizeAttenuation: true
    });

    const points = new THREE.Points(geometry, material);
    scene.add(points);

    let frameId;
    function animate() {
      frameId = requestAnimationFrame(animate);
      const posAttr = geometry.attributes.position;
      for (let i = 0; i < count; i++) {
        let y = posAttr.getY(i);
        y += speeds[i] * 0.01;
        if (y > 6) y = -6;
        posAttr.setY(i, y);
      }
      posAttr.needsUpdate = true;
      points.rotation.y += 0.0006;
      renderer.render(scene, camera);
    }
    animate();

    // Handle resize
    window.addEventListener('resize', () => {
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    });

    // Pause when tab hidden (perf)
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        cancelAnimationFrame(frameId);
      } else {
        animate();
      }
    });
  }
})();
