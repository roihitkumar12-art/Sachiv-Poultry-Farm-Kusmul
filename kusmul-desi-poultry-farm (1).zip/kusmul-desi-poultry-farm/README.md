# Sachiv Poultry Farm Kusmul — Website

Bhathapara, Kusmul, Sakti, Chhattisgarh - 495695 ke desi poultry farm ke liye banaya gaya complete website.

## 📁 Structure

```
Sachiv-poultry-farm-kusmul/
├── index.html          Homepage
├── about.html           Hamare baare me / farm history
├── farm.html             Daily process, hygiene practices
├── products.html      Murgi + Ande listing, WhatsApp order
├── gallery.html         Filterable image gallery + lightbox
├── blog.html              Articles listing
├── contact.html         Enquiry form + map + contact info
├── faq.html                Accordion FAQ
├── privacy.html         Privacy policy
├── css/
│   ├── variables.css   Design tokens (colors, fonts, spacing)
│   ├── style.css           Main layout & components
│   ├── animation.css   Keyframes, scroll reveal, hero load
│   └── responsive.css  Mobile/tablet breakpoints
├── js/
│   ├── app.js               Forms, WhatsApp order buttons, utilities
│   ├── menu.js             Mobile nav toggle, header scroll state
│   ├── slider.js           Testimonial/image carousel (optional use)
│   ├── counter.js         Animated stat counters
│   ├── animation.js    Scroll reveal + FAQ accordion + gallery filter
│   └── three.js             Optional ambient particle effect (hero)
└── assets/
    ├── images/           Farm/product/gallery photos (placeholders included)
    ├── icons/
    ├── videos/
    ├── models/
    └── logo/               favicon.png
```

## 🎨 Design System

- **Haldi (turmeric) yellow** `#D9A62E` — primary brand accent
- **Mitti (earthen clay) brown** `#8B4A2B` — secondary/CTA
- **Neem green** `#3D5A3D` — trust, WhatsApp accent
- **Rice husk cream** `#F2E8D5` — background
- **Diya orange** `#E8622C` — call-to-action highlight
- Fonts: **Baloo 2** (display/headings), **Hind** (body), **Rajdhani** (labels/utility) — all Devanagari + Latin friendly, loaded from Google Fonts.

All tokens live in `css/variables.css` — change a color once, it updates everywhere.

## ⚙️ IMPORTANT: Before Going Live

1. **Phone/WhatsApp number** — Replace the placeholder `+919926030249` in:
   - Every `.html` file (`tel:` links, `nav-phone`, footer, WhatsApp float button)
   - `js/app.js` → `FARM_PHONE` and `FARM_WHATSAPP` constants
   
   Quick way: use find-and-replace across all files for `919926030249`.

2. **Email address** — Replace `info@kusmuldesipoultry.com` with your real email in all files.

3. **Real photos** — Replace placeholder images in `assets/images/` with actual farm photos. Keep the same filenames or update the `src` in HTML accordingly. Recommended: compress images (use [squoosh.app](https://squoosh.app)) before uploading — keeps the site fast on mobile data.

4. **Google Maps** — In `contact.html`, the map currently searches "Sakti, Chhattisgarh". For a pin-accurate location:
   - Go to Google Maps → search your exact farm location → Share → Embed a map → copy the `src` URL → paste into the `<iframe src="...">` in `contact.html`.

5. **Social links** — Footer has placeholder `#` links for Facebook/Instagram/YouTube — update with real profile URLs.

## 🚀 How to Use

- **Preview locally**: just double-click `index.html`, or run a local server:
  ```
  cd kusmul-desi-poultry-farm
  python3 -m http.server 8000
  ```
  then open `http://localhost:8000`

- **Deploy free**: Upload the whole folder to [Netlify Drop](https://app.netlify.com/drop), [Vercel](https://vercel.com), or GitHub Pages — no build step needed, it's plain HTML/CSS/JS.

## ✨ Features Included

- Fully responsive (mobile/tablet/desktop)
- Hindi + English (Hinglish) content throughout
- WhatsApp click-to-order buttons on every product
- Animated hero stats counter
- Scroll-reveal animations (respects `prefers-reduced-motion`)
- Filterable gallery with lightbox
- FAQ accordion
- Working contact form (client-side validation; currently shows a success message — connect to a backend/Formspree/EmailJS if you want real email delivery)
- Sticky WhatsApp floating button
- SEO-friendly meta tags on every page

## 📝 Notes

- The contact form currently validates and shows a success message but does **not** send an email — it's front-end only. To actually receive form submissions, connect it to a free service like [Formspree](https://formspree.io) or [EmailJS](https://www.emailjs.com), or ask for help wiring up a backend.
- `three.js` ambient particle effect on the homepage hero is optional and loads from CDN — if it fails to load (e.g., no internet), the site still works perfectly fine without it.
